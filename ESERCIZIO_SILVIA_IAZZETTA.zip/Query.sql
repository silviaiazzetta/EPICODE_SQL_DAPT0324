-- CREAZIONE SCHEMA TOYS
CREATE SCHEMA toys;

-- CREAZIONE TABELLA PRODUCT
CREATE TABLE product (
    productID INT PRIMARY KEY,
    nome_prodotto VARCHAR(100),
    categoria_prodotto VARCHAR(100)
);

-- CREAZIONE TABELLA REGION
CREATE TABLE region (
    regionID INT PRIMARY KEY,
    nome_regione VARCHAR(100)
);

-- CREAZIONE TABELLA SALES
CREATE TABLE sales (
    salesID INT PRIMARY KEY,
    productID INT,
    regionID INT,
    quantità INT,
    prezzo_unitario DECIMAL (10, 2),
    data_vendita DATE,
    FOREIGN KEY (productID)
        REFERENCES product (productID),
    FOREIGN KEY (regionID)
        REFERENCES region (regionID)
);

-- POPOLAMENTO TABELLA PRODUCT
INSERT INTO product VALUES
(1, 'Barbie', 'Bambola'),
(2, 'Lego', 'Giocattoli educativi'),
(3, 'Twister', 'Gioco di società'),
(4, 'Monopoli', 'Gioco di società'),
(5, 'Transformes', 'Bambola'),
(6, 'Il Cubo di Rubrik', 'Giocattoli educativi'),
(7, 'Cicciobello', 'Bambola'),
(8, 'Nintendo Switch', 'Giocattoli elettronici'),
(9, 'PlayStation', 'Giocattoli elettronici'),
(10, 'Risiko', 'Gioco di società');

-- POPOLAMENTO TABELLA REGION
INSERT INTO region VALUES 
(1, 'Europa'),
(2, 'America Settentrionale'),
(3, 'America Meridionale'),
(4, 'America Centrale'),
(5, 'Asia'),
(6, 'Oceania'),
(7, 'Africa');

-- POPOLAMENTO TABELLA SALES
INSERT INTO sales VALUES 
(1, 2, 1, 5, 50.00, '2024-05-10'),
(2, 6, 2, 10, 5.00, '2023-07-24'),
(3, 5, 3, 4, 30.00, '2024-06-01'),
(4, 1, 1, 22, 20.00, '2023-07-10'),
(5, 3, 1, 11, 15.00, '2022-07-03'),
(6, 4, 2, 15, 20.00, '2024-06-07'),
(7, 10, 2, 3, 20.00, '2024-06-22'),
(8, 9, 2, 20, 200.00, '2023-07-19'),
(9, 8, 4, 5, 150.00, '2024-06-05'),
(10, 5, 1, 14, 30.00, '2023-01-04'),
(11, 4, 1, 10, 20.00, '2022-02-05'),
(12, 2, 5, 12, 50.00, '2022-08-08'),
(13, 6, 5, 21, 5.00, '2022-02-13'),
(14, 8, 2, 8, 150.00, '2023-12-11'),
(15, 1, 5, 7, 20.00, '2022-12-18'),
(16, 9, 6, 15, 200.00, '2023-07-01'),
(17, 4, 6, 9, 20.00, '2022-09-06'),
(18, 6, 7, 6, 5.00, '2023-08-07'),
(19, 10, 4, 7, 20.00, '2024-03-17'),
(20, 3, 3, 21, 15.00, '2022-11-04'),
(21, 3, 4, 16, 15.00, '2024-07-11'),
(22, 2, 7, 10, 50.00, '2024-06-10');

-- 1. VERIFICARE CHE I CAMPI DEFINITI COME PK SIANO UNIVOCI.
-- PER LA TABELLA PRODUCT
SELECT 
    COUNT(productID) AS ConteggioRighe,
    COUNT(DISTINCT productID) AS ConteggioDistinct
FROM
    product;
    
-- PER LA TABELLA REGION
SELECT 
    COUNT(regionID) AS ConteggioRighe,
    COUNT(DISTINCT regionID) AS ConteggioDistinct
FROM
    region;
    
-- PER LA TABELLA SALES
SELECT 
    COUNT(salesID) AS ConteggioRighe,
    COUNT(DISTINCT salesID) AS ConteggioDistinct
FROM
    sales;

-- 2. ESPORRE L'ELENCO DEI SOLI PRODOTTI VENDUTI E PER OGNUNO DI QUESTI IL FATTURATO TOTALE PER ANNO.
SELECT 
    p.nome_prodotto,
    p.categoria_prodotto,
    SUM(s.quantità * s.prezzo_unitario) AS fatturato_totale,
    YEAR(s.data_vendita) AS anno
FROM
    sales AS s
        JOIN
    product AS p ON p.productID = s.productID
WHERE
    s.productID IS NOT NULL
GROUP BY p.nome_prodotto , p.categoria_prodotto , anno;

-- 3. ESPORRE IL FATTURATO TOTALE PER STATO PER ANNO. ORDINA IL RISULTATO PER DATA E PER FATTURATO DECRESCENTE.
SELECT 
    YEAR(s.data_vendita) AS anno,
    SUM(s.quantità * s.prezzo_unitario) AS fatturato_totale,
    r.nome_regione
FROM
    sales AS s
        JOIN
    region AS r ON r.regionID = s.regionID
GROUP BY r.nome_regione , anno
ORDER BY anno , fatturato_totale DESC;

-- 4. RISPONDERE ALLA SEGUENTE DOMANDA: QUAL E' LA CATEGORIA DI ARTICOLI MAGGIORMENTE RICHIESTA DAL MERCATO?
SELECT 
    SUM(s.quantità) AS quantità_totale,
    p.categoria_prodotto
FROM
    sales AS s
        JOIN
    product AS p ON p.productID = s.productID
GROUP BY p.categoria_prodotto
ORDER BY quantità_totale DESC;
-- LA CATEGORIA DI PRODOTTO MAGGIORMENTE RICHIESTA DAL MERCATO SONO I GIOCHI DI SOCIETA'.

-- 5. RISPONDERE ALLA SEGUENTE DOMANDA: QUALI SONO, SE CI SONO, I PRODOTTI INVENDUTI? PROPONI DUE APPROCCI RISOLUTIVI DIFFERENTI.
-- APPROCCIO 1
SELECT * 
FROM product 
WHERE productID NOT IN (SELECT productID FROM sales);

-- APPROCCIO 2
SELECT *
FROM product AS p
LEFT JOIN sales AS s ON p.productID = s.productID
WHERE s.productID IS NULL;
-- IL PRODOTTO RIMASTO INVENDUTO E' CICCIOBELLO.

-- 6. ESPORRE L'ELENCO DEI PRODOTTI CON LA RISPETTIVA ULTIMA DATA DI VENDITA (LA DATA DI VENDITA PIU' RECENTE).
SELECT 
    p.nome_prodotto, p.categoria_prodotto, MAX(s.data_vendita) AS ultima_data_vendita
FROM
    product AS p
        JOIN
    sales AS s ON s.productID = p.productID
GROUP BY p.nome_prodotto, p.categoria_prodotto

